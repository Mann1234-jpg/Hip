package com.mrgames.highway;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText emailInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);

        Button loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(v -> {
            String email = emailInput.getText().toString();
            String password = passwordInput.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email or Password is empty", Toast.LENGTH_SHORT).show();
            } else {
                // TODO: Integrate FirebaseAuth logic here
                Toast.makeText(this, "Login attempt with: " + email, Toast.LENGTH_SHORT).show();
            }
        });

        Button retryButton = findViewById(R.id.retry_button);
        retryButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "Retry Clicked! Restarting journey...", Toast.LENGTH_SHORT).show();
        });

        Button ghostButton = findViewById(R.id.ghost_button);
        ghostButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "👻 A terrifying presence approaches!", Toast.LENGTH_LONG).show();
        });

        Button policeButton = findViewById(R.id.police_button);
        policeButton.setOnClickListener(v -> {
            Toast.makeText(MainActivity.this, "🚓 Police confused by vanishing signal...", Toast.LENGTH_LONG).show();
        });
    }
}
